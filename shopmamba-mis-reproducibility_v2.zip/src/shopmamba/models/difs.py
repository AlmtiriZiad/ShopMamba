"""Dynamic Imbalance-Focal Sampler (DIFS), Eq. (27)-(33).

    pi_hat_t (batch) = mean(y_i)                                        Eq. (28)
    pi_t = beta * pi_{t-1} + (1 - beta) * pi_hat_t                       Eq. (29)
    gamma_t = clip(gamma_min + (gamma_max - gamma_min) * (pi_max - pi_t) / (pi_max - pi_min),
                   gamma_min, gamma_max)                                 Eq. (30)
    L_FL(y, p; gamma_t) = -alpha_t(y) (1 - p_t)^gamma_t log p_t          Eq. (31)
    alpha_t(1) = 1 - pi_t ,  alpha_t(0) = pi_t
Constants: beta = 0.99, gamma_min = 0.5, gamma_max = 5.0, pi_min = 0.0002, pi_max = 0.03.
For IECIS (pi_t ~ 0.035 > pi_max) the clip assigns gamma_t = gamma_min = 0.5 throughout
training, exactly as stated in the paper. static_gamma=2.0 reproduces ablation A3.
"""
import torch
import torch.nn as nn
import torch.nn.functional as F


class DIFS(nn.Module):
    def __init__(self, beta=0.99, gamma_min=0.5, gamma_max=5.0, pi_min=0.0002, pi_max=0.03,
                 pi_init=None, static_gamma=None):
        super().__init__()
        self.beta, self.gmin, self.gmax, self.pmin, self.pmax = beta, gamma_min, gamma_max, pi_min, pi_max
        self.static_gamma = static_gamma
        # EMA state is a buffer so it is saved with checkpoints (Flink snapshotState analogue)
        self.register_buffer("pi", torch.tensor(float(pi_init) if pi_init is not None else 0.0))
        self.register_buffer("initialised", torch.tensor(pi_init is not None))
        self.frozen = False           # True at streaming inference (delayed labels only)

    @torch.no_grad()
    def update(self, y):
        if self.frozen:
            return
        pi_hat = y.float().mean()                                          # Eq. (28)
        if not bool(self.initialised):
            self.pi.copy_(pi_hat); self.initialised.fill_(True)
        else:
            self.pi.mul_(self.beta).add_((1 - self.beta) * pi_hat)          # Eq. (29)

    def gamma(self):
        if self.static_gamma is not None:
            return torch.tensor(self.static_gamma, device=self.pi.device)
        g = self.gmin + (self.gmax - self.gmin) * (self.pmax - self.pi) / (self.pmax - self.pmin)
        return g.clamp(self.gmin, self.gmax)                                # Eq. (30)

    def focal_loss(self, logits, y):
        p = torch.sigmoid(logits)
        p_t = torch.where(y > 0.5, p, 1 - p).clamp_min(1e-7)
        if self.static_gamma is not None:
            alpha = torch.full_like(y, 0.25).where(y < 0.5, torch.full_like(y, 0.75))   # standard focal alpha
        else:
            alpha = torch.where(y > 0.5, 1 - self.pi, self.pi)              # alpha_t(y)
        return (-alpha * (1 - p_t) ** self.gamma() * torch.log(p_t)).mean()  # Eq. (31)-(32)
