"""Full SHOPMAMBA-MIS model: SSAE -> TAM -> classification head, with DIFS loss.

Anomaly score s_t in [0, 1] combines the classification head output and the
normalised reconstruction residual (Eq. 3 uses s_t >= delta). Total objective
L = L_FL + lambda * L_recon with lambda = 0.3 (Eq. 33).
"""
import torch
import torch.nn as nn

from .ssae import SSAE
from .tam import TAM
from .difs import DIFS


class ShopMambaMIS(nn.Module):
    def __init__(self, d_in, d_state=64, d_latent=64, window=16, lam=0.3,
                 selective=True, use_tam=True, static_gamma=None, difs_kwargs=None):
        super().__init__()
        self.ssae = SSAE(d_in, d_state, d_latent, selective=selective)
        self.tam = TAM(d_latent, window) if use_tam else None
        self.head = nn.Linear(d_latent + 1, 1)
        self.difs = DIFS(static_gamma=static_gamma, **(difs_kwargs or {}))
        self.lam = lam

    def forward(self, x):                       # x: (B, L, d)
        z, x_hat, r = self.ssae(x)
        if self.tam is not None:
            z = self.tam(z)
        r_last = torch.log1p(r[:, -1:])         # residual of the final token
        logit = self.head(torch.cat([z[:, -1], r_last], -1)).squeeze(-1)
        return logit, r

    def score(self, x):
        logit, _ = self.forward(x)
        return torch.sigmoid(logit)             # s_t

    def loss(self, x, y):
        logit, r = self.forward(x)
        self.difs.update(y)
        return self.difs.focal_loss(logit, y) + self.lam * r.mean()        # Eq. (33)


def build_from_config(cfg, d_in):
    m = cfg["model"]
    return ShopMambaMIS(d_in, d_state=m["d_state"], d_latent=m["d_latent"], window=m["tam_window"],
                        lam=m["lambda"], selective=m.get("selective", True), use_tam=m.get("use_tam", True),
                        static_gamma=m.get("static_gamma"),
                        difs_kwargs=dict(beta=m["ema_beta"], gamma_min=m["gamma_min"], gamma_max=m["gamma_max"],
                                         pi_min=m["pi_min"], pi_max=m["pi_max"]))
