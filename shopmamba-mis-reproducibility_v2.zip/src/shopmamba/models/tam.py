"""Transaction Attention Module (TAM), Eq. (20)-(26).

Causal windowed attention over the last W = 16 tokens:
    e_{t,k}     = (W_Q z_t)^T (W_K z_k) / sqrt(M),   k in window(t)     Eq. (20)
    theta_{t,k} = softmax_k(e_{t,k})                                     Eq. (21)
    z_t^(TAM)   = sum_k theta_{t,k} (W_V z_k) + z_t                      Eq. (22)
Complexity O(L * W) instead of O(L^2). Disabled in ablation A2.
"""
import math

import torch
import torch.nn as nn


class TAM(nn.Module):
    def __init__(self, d_latent: int = 64, window: int = 16):
        super().__init__()
        self.W = window
        self.q, self.k, self.v = (nn.Linear(d_latent, d_latent, bias=False) for _ in range(3))
        self.scale = 1.0 / math.sqrt(d_latent)

    def forward(self, z, return_weights: bool = False):     # z: (B, L, M)
        B, L, M = z.shape
        q, k, v = self.q(z), self.k(z), self.v(z)
        pad = self.W - 1
        k_p = torch.cat([k.new_zeros(B, pad, M), k], 1)   # left pad so every window is causal
        v_p = torch.cat([v.new_zeros(B, pad, M), v], 1)
        k_win = k_p.unfold(1, self.W, 1)                  # (B, L, M, W)
        v_win = v_p.unfold(1, self.W, 1)
        e = torch.einsum("blm,blmw->blw", q, k_win) * self.scale          # Eq. (20)
        valid = torch.arange(L, device=z.device).unsqueeze(1) + torch.arange(-pad, 1, device=z.device) >= 0
        e = e.masked_fill(~valid.unsqueeze(0), float("-inf"))
        theta = torch.softmax(e, dim=-1)                                   # Eq. (21)
        out = torch.einsum("blw,blmw->blm", theta, v_win) + z              # Eq. (22), residual
        return (out, theta) if return_weights else out
