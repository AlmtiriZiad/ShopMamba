"""Selective-State Autoencoder (SSAE), Eq. (14)-(19).

Discretised selective SSM (Eq. 14-16):
    A_bar_t = exp(Delta_t A)
    B_bar_t = (Delta_t A)^{-1} (exp(Delta_t A) - I) Delta_t B_t
    h_t     = A_bar_t h_{t-1} + B_bar_t x_t
with input-dependent Delta_t and B_t (selectivity). A linear decoder (Eq. 18)
reconstructs x_hat_t = W_dec h_t^(dec) + b_dec, and the per-token residual
r_t = ||x_t - x_hat_t||_2^2 (Eq. 19) feeds the anomaly score. Setting
selective=False freezes Delta and B (ablation A1).
"""
import math

import torch
import torch.nn as nn
import torch.nn.functional as F


class SelectiveSSM(nn.Module):
    def __init__(self, d_model: int, d_state: int = 64, selective: bool = True):
        super().__init__()
        self.d_model, self.d_state, self.selective = d_model, d_state, selective
        # diagonal A initialised as -(1..N) (S4D-real style), kept negative via -exp
        self.A_log = nn.Parameter(torch.log(torch.arange(1, d_state + 1, dtype=torch.float32)).repeat(d_model, 1))
        self.D = nn.Parameter(torch.ones(d_model))
        if selective:
            self.x_proj = nn.Linear(d_model, 1 + 2 * d_state, bias=False)   # Delta, B_t, C_t
            self.dt_proj = nn.Linear(1, d_model, bias=True)
        else:
            self.B = nn.Parameter(torch.randn(d_model, d_state) * 0.02)
            self.C = nn.Parameter(torch.randn(d_model, d_state) * 0.02)
            self.log_dt = nn.Parameter(torch.full((d_model,), math.log(0.01)))

    def forward(self, x):                      # x: (B, L, d)
        Bsz, L, d = x.shape
        A = -torch.exp(self.A_log)             # (d, N), strictly negative
        if self.selective:
            dt_raw, Bt, Ct = torch.split(self.x_proj(x), [1, self.d_state, self.d_state], dim=-1)
            dt = F.softplus(self.dt_proj(dt_raw))          # (B, L, d)  Delta_t
            Bt = Bt.unsqueeze(2).expand(-1, -1, d, -1)     # (B, L, d, N)
            Ct = Ct.unsqueeze(2).expand(-1, -1, d, -1)
        else:
            dt = torch.exp(self.log_dt).view(1, 1, d).expand(Bsz, L, d)
            Bt = self.B.view(1, 1, d, self.d_state).expand(Bsz, L, -1, -1)
            Ct = self.C.view(1, 1, d, self.d_state).expand(Bsz, L, -1, -1)
        dA = dt.unsqueeze(-1) * A                          # (B, L, d, N) = Delta_t A
        A_bar = torch.exp(dA)                              # Eq. (14)
        B_bar = (A_bar - 1.0) / A * Bt * 1.0               # (Delta A)^-1 (exp(Delta A)-I) Delta B  (diagonal A)
        h = x.new_zeros(Bsz, d, self.d_state)
        ys = []
        for t in range(L):                                 # O(L) linear-time recurrence, Eq. (16)
            h = A_bar[:, t] * h + B_bar[:, t] * x[:, t].unsqueeze(-1)
            ys.append((h * Ct[:, t]).sum(-1))              # y_t = C_t h_t, Eq. (17)
        y = torch.stack(ys, dim=1)
        return y + self.D * x, h


class SSAE(nn.Module):
    """Encoder SSM -> latent (M) -> decoder SSM -> linear reconstruction."""

    def __init__(self, d_in: int, d_state: int = 64, d_latent: int = 64, selective: bool = True):
        super().__init__()
        self.in_proj = nn.Linear(d_in, d_latent)
        self.enc = SelectiveSSM(d_latent, d_state, selective)
        self.dec = SelectiveSSM(d_latent, d_state, selective)
        self.out = nn.Linear(d_latent, d_in)               # W_dec, b_dec  Eq. (18)
        self.norm = nn.LayerNorm(d_latent)

    def forward(self, x):
        z = self.norm(self.in_proj(x))
        z_enc, _ = self.enc(z)                             # token-level representations z_t
        z_dec, _ = self.dec(z_enc)
        x_hat = self.out(z_dec)                            # Eq. (18)
        r = ((x - x_hat) ** 2).sum(-1)                     # r_t, Eq. (19)
        return z_enc, x_hat, r
