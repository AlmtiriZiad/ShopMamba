"""SHOPMAMBA-MIS reference implementation (SSAE + TAM + DIFS)."""
__version__ = "1.0.0"
