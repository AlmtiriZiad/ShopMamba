"""Dataset-specific loaders for IEEE-CIS (IECIS), PaySim and ULB Credit Card Fraud.

Raw Kaggle files are expected under data/raw/<dataset>/ (see data/README.md).
Each loader returns a DataFrame with the columns
    account_id  : surrogate account key used for sequence grouping (None for ULB)
    t           : chronological ordering key (TransactionDT / step / Time)
    label       : 1 = fraud, 0 = legitimate
    f_0 .. f_d-1: numeric feature columns (d = 433 / 11 / 30, Table 3)
and writes it to data/processed/<dataset>.parquet.
"""
import argparse
from pathlib import Path

import numpy as np
import pandas as pd

ROOT = Path(__file__).resolve().parents[3]
RAW, PROC = ROOT / "data" / "raw", ROOT / "data" / "processed"

EXPECTED_ROWS = {"ieee-cis": 590_540, "paysim": 6_354_407, "ulb": 284_807}
EXPECTED_FEATURES = {"ieee-cis": 433, "paysim": 11, "ulb": 30}


def _finalise(df, name, feat_cols):
    assert len(df) == EXPECTED_ROWS[name], f"{name}: {len(df)} rows, expected {EXPECTED_ROWS[name]}"
    assert len(feat_cols) == EXPECTED_FEATURES[name], f"{name}: {len(feat_cols)} features"
    df = df.sort_values(["t"], kind="stable").reset_index(drop=True)
    feats = df[feat_cols].apply(pd.to_numeric, errors="coerce").fillna(0.0).astype(np.float32)
    feats.columns = [f"f_{i}" for i in range(len(feat_cols))]
    out = pd.concat([df[["account_id", "t", "label"]].reset_index(drop=True), feats], axis=1)
    PROC.mkdir(parents=True, exist_ok=True)
    out.to_parquet(PROC / f"{name}.parquet", index=False)
    return out


def load_ieee_cis():
    """590,540 x 433 (394 transaction + 41 identity columns minus keys, minus isFraud)."""
    tr = pd.read_csv(RAW / "ieee-cis" / "train_transaction.csv")
    idn = pd.read_csv(RAW / "ieee-cis" / "train_identity.csv")
    df = tr.merge(idn, on="TransactionID", how="left")
    cards = ["card1", "card2", "card3", "card4", "card5", "card6"]
    df["account_id"] = df[cards].astype(str).agg("|".join, axis=1)
    df["t"] = df["TransactionDT"]
    df["label"] = df["isFraud"].astype(np.int8)
    drop = {"TransactionID", "isFraud", "TransactionDT", "account_id", "t", "label"}
    feat_cols = [c for c in df.columns if c not in drop]
    for c in feat_cols:
        if df[c].dtype == object:
            df[c] = df[c].astype("category").cat.codes
    return _finalise(df, "ieee-cis", feat_cols)


def load_paysim():
    df = pd.read_csv(RAW / "paysim" / "PS_20174392719_1491204439457_log.csv")
    df["account_id"] = df["nameOrig"]
    df["t"] = df["step"]
    df["label"] = df["isFraud"].astype(np.int8)
    df["type"] = df["type"].astype("category").cat.codes
    df["dest_is_merchant"] = df["nameDest"].str.startswith("M").astype(np.int8)
    df["delta_orig"] = df["newbalanceOrig"] - df["oldbalanceOrg"]
    df["delta_dest"] = df["newbalanceDest"] - df["oldbalanceDest"]
    feat_cols = ["step", "type", "amount", "oldbalanceOrg", "newbalanceOrig", "oldbalanceDest",
                 "newbalanceDest", "isFlaggedFraud", "dest_is_merchant", "delta_orig", "delta_dest"]
    return _finalise(df, "paysim", feat_cols)


def load_ulb():
    df = pd.read_csv(RAW / "ulb-creditcard" / "creditcard.csv")
    df["account_id"] = None          # no account identifier exists (Section 6.1)
    df["t"] = df["Time"]
    df["label"] = df["Class"].astype(np.int8)
    feat_cols = ["Time"] + [f"V{i}" for i in range(1, 29)] + ["Amount"]
    return _finalise(df, "ulb", feat_cols)


LOADERS = {"ieee-cis": load_ieee_cis, "paysim": load_paysim, "ulb": load_ulb}


def load_processed(name):
    return pd.read_parquet(PROC / f"{name}.parquet")


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--dataset", choices=LOADERS)
    ap.add_argument("--all", action="store_true")
    a = ap.parse_args()
    for n in (LOADERS if a.all else [a.dataset]):
        print(n, LOADERS[n]().shape)
