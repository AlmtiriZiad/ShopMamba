"""Behavioural sequence construction (Section 6.1).

A sliding window of length L = 512 with stride 1 is applied inside each
account group (IECIS: card1..card6 key; PaySim: nameOrig; ULB: global time order).
The label of the final token in each window is the sequence label. Windows never
cross partition boundaries; transactions with fewer than L prior events in their
partition are cold-start (WAIT status, Algorithm 2) and are excluded from metric
computation.
"""
import numpy as np
import torch
from torch.utils.data import Dataset


class WindowDataset(Dataset):
    def __init__(self, feats: np.ndarray, labels: np.ndarray, groups, L: int = 512):
        self.X = torch.as_tensor(feats, dtype=torch.float32)
        self.y = torch.as_tensor(labels, dtype=torch.float32)
        self.L = L
        order = np.arange(len(labels))
        self.ends, self.cold_start = [], 0
        if groups is None:                       # ULB: one global chronological stream
            groups = np.zeros(len(labels), dtype=np.int64)
        for g in np.unique(groups):
            rows = order[groups == g]
            for j in range(len(rows)):
                if j + 1 < L:
                    self.cold_start += 1        # WAIT
                else:
                    self.ends.append(rows[j - L + 1: j + 1])
        self.ends = np.asarray(self.ends, dtype=np.int64)

    def __len__(self):
        return len(self.ends)

    def __getitem__(self, i):
        rows = self.ends[i]
        return self.X[rows], self.y[rows[-1]]


def make_windows(df, index, L=512):
    sub = df.iloc[index]
    feats = sub[[c for c in sub.columns if c.startswith("f_")]].values
    groups = None if sub["account_id"].isna().all() else sub["account_id"].astype("category").cat.codes.values
    return WindowDataset(feats, sub["label"].values, groups, L)
