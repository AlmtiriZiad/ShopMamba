"""Chronological train / validation / test partitioning (Table 3, Section 6.1).

No random shuffling is applied at any stage. Split boundaries are defined on the
ordering field t and materialised as row-index JSON files in data/splits/ so that
every run and every baseline uses identical partitions. Expected partition sizes
are asserted against data/splits/expected_sizes.json.
"""
import argparse
import json
from pathlib import Path

import numpy as np

from .loaders import load_processed

ROOT = Path(__file__).resolve().parents[3]
SPLITS = ROOT / "data" / "splits"

# fractions of rows (in chronological order) assigned to train / val / test
FRACTIONS = {
    "ieee-cis": (None, 0.15, 114_209 / 590_540),   # test fixed to 114,209 rows; val = 15 % of remainder
    "paysim":   (0.70, 0.15, 0.15),
    "ulb":      (0.80, 0.10, 0.10),
}


def make_split(name, df):
    n = len(df)
    tr_f, va_f, te_f = FRACTIONS[name]
    n_test = int(round(te_f * n))
    if name == "ieee-cis":
        n_test = 114_209
        n_val = int(round(va_f * (n - n_test)))
    else:
        n_val = int(round(va_f * n))
    n_train = n - n_val - n_test
    idx = np.arange(n)      # df is already sorted by t in loaders._finalise
    return {"train": idx[:n_train].tolist(),
            "val": idx[n_train:n_train + n_val].tolist(),
            "test": idx[n_train + n_val:].tolist()}


def check_sizes(name, split, labels):
    exp = json.loads((SPLITS / "expected_sizes.json").read_text())[name]
    got_rows, got_pos = len(split["test"]), int(labels[split["test"]].sum())
    assert got_rows == exp["test_rows"], f"{name}: test rows {got_rows} != {exp['test_rows']}"
    assert got_pos == exp["test_positives"], f"{name}: test positives {got_pos} != {exp['test_positives']}"


def build(name):
    df = load_processed(name)
    split = make_split(name, df)
    check_sizes(name, split, df["label"].values)
    (SPLITS / f"{name}_split.json").write_text(json.dumps(split))
    return split


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--dataset", choices=FRACTIONS)
    ap.add_argument("--all", action="store_true")
    a = ap.parse_args()
    for n in (FRACTIONS if a.all else [a.dataset]):
        s = build(n)
        print(n, {k: len(v) for k, v in s.items()})
