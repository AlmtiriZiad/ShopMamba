"""Median inference latency per batch on the deployment CPU (Section 6.3, Figure 9).

Measures 1,000 forward passes on an Intel Xeon E5-2690 v4 restricted to 2 threads,
batch size 1 sequence of length L, after 50 warm-up passes.
"""
import argparse
import statistics
import time

import torch
import yaml

from ..models.shopmamba_mis import build_from_config


def bench(model, d_in, L, n=1000, warmup=50):
    torch.set_num_threads(2)
    model.eval(); x = torch.randn(1, L, d_in)
    with torch.no_grad():
        for _ in range(warmup):
            model.score(x)
        ts = []
        for _ in range(n):
            t0 = time.perf_counter(); model.score(x); ts.append((time.perf_counter() - t0) * 1e3)
    return statistics.median(ts)


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--config", default="configs/model/shopmamba_mis.yaml")
    ap.add_argument("--d_in", type=int, default=433)
    ap.add_argument("--L", type=int, nargs="+", default=[64, 128, 256, 512, 1024])
    ap.add_argument("--checkpoint")
    a = ap.parse_args()
    cfg = yaml.safe_load(open(a.config))
    m = build_from_config(cfg, a.d_in)
    if a.checkpoint:
        m.load_state_dict(torch.load(a.checkpoint, map_location="cpu")["model"])
    for L in a.L:
        print(f"L={L}\tmedian_ms={bench(m, a.d_in, L):.2f}")
