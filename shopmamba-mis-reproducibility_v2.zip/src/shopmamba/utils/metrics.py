"""Seven evaluation metrics of Section 6.3 plus the raw confusion matrix.

F1 (Eq. 4), Precision, Recall, AUROC (Eq. 35), AUPRC (Eq. 36), FPR (Eq. 6), MCC (Eq. 37).
All ratio metrics are computed from the integer confusion matrix so that Table 5 is
reconstructible from Table 6 by construction.
"""
import math

import numpy as np
from sklearn.metrics import average_precision_score, roc_auc_score


def confusion(y_true, y_pred):
    y_true, y_pred = np.asarray(y_true).astype(int), np.asarray(y_pred).astype(int)
    tp = int(((y_true == 1) & (y_pred == 1)).sum()); fp = int(((y_true == 0) & (y_pred == 1)).sum())
    fn = int(((y_true == 1) & (y_pred == 0)).sum()); tn = int(((y_true == 0) & (y_pred == 0)).sum())
    return dict(tp=tp, fp=fp, fn=fn, tn=tn)


def from_confusion(tp, fp, fn, tn):
    prec = tp / (tp + fp) if tp + fp else 0.0
    rec = tp / (tp + fn) if tp + fn else 0.0
    f1 = 2 * prec * rec / (prec + rec) if prec + rec else 0.0
    fpr = fp / (fp + tn) if fp + tn else 0.0
    den = math.sqrt((tp + fp) * (tp + fn) * (tn + fp) * (tn + fn))
    mcc = (tp * tn - fp * fn) / den if den else 0.0
    return dict(f1=f1, precision=prec, recall=rec, fpr=fpr, mcc=mcc)


def evaluate(y_true, scores, delta):
    y_pred = (np.asarray(scores) >= delta).astype(int)
    cm = confusion(y_true, y_pred)
    out = from_confusion(**cm)
    out["auroc"] = float(roc_auc_score(y_true, scores))
    out["auprc"] = float(average_precision_score(y_true, scores))
    out.update(cm)
    return out


def calibrate_threshold(y_val, scores_val, fpr_max=0.005):
    """Largest-recall delta on the validation split subject to FPR <= FPR_max (Eq. 3, 6)."""
    s = np.asarray(scores_val); y = np.asarray(y_val)
    best = (1.0, -1.0)
    for d in np.unique(s):
        pred = s >= d
        fpr = ((pred) & (y == 0)).sum() / max(1, (y == 0).sum())
        if fpr <= fpr_max:
            rec = ((pred) & (y == 1)).sum() / max(1, (y == 1).sum())
            if rec > best[1]:
                best = (float(d), float(rec))
    return best[0]
