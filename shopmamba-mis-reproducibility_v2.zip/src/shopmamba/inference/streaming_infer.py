"""Algorithm 2: streaming inference with frozen EMA state and delayed-label recalibration.

Per-account ring buffers of length L feed the trained model one transaction at a time.
The DIFS EMA is frozen during scoring; it is updated only when analyst-confirmed labels
arrive (4-24 h delay). Threshold delta is recalibrated hourly on a 72 h rolling window of
confirmed labels. snapshot()/restore() expose all mutable state for Flink checkpointing.
"""
from collections import deque

import numpy as np
import torch

from .decision_routing import route
from ..training.ema_estimator import EMAFraudRate
from ..utils.metrics import calibrate_threshold


class StreamingScorer:
    def __init__(self, model, L=512, delta=0.5, beta=0.99, pi_init=0.0, fpr_max=0.005):
        self.model, self.L, self.delta, self.fpr_max = model.eval(), L, delta, fpr_max
        self.buffers = {}
        self.ema = EMAFraudRate(beta=beta, pi=pi_init, initialised=True)
        if hasattr(model, "difs"):
            model.difs.frozen = True
        self.confirmed = deque()        # (timestamp, score, label) for hourly recalibration

    def process_element(self, account_id, features, ts):
        buf = self.buffers.setdefault(account_id, deque(maxlen=self.L))
        buf.append(np.asarray(features, dtype=np.float32))
        if len(buf) < self.L:
            return None, route(0.0, self.delta, cold_start=True)
        x = torch.from_numpy(np.stack(buf)).unsqueeze(0)
        with torch.no_grad():
            s = float(self.model.score(x)[0])
        return s, route(s, self.delta)

    def on_confirmed_labels(self, batch):            # batch: iterable of (ts, score, label)
        labels = [b[2] for b in batch]
        if labels:
            pi = self.ema.update(float(np.mean(labels)))
            if hasattr(self.model, "difs"):
                self.model.difs.pi.fill_(pi)
        self.confirmed.extend(batch)

    def hourly_recalibrate(self, now, window_h=72):
        while self.confirmed and self.confirmed[0][0] < now - window_h * 3600:
            self.confirmed.popleft()
        if len(self.confirmed) >= 100:
            y = [c[2] for c in self.confirmed]; s = [c[1] for c in self.confirmed]
            self.delta = calibrate_threshold(y, s, self.fpr_max)
        return self.delta

    # Flink stateful-operator interface --------------------------------------
    def snapshot_state(self):
        return {"delta": self.delta, "ema": self.ema.snapshot(),
                "buffers": {k: np.stack(v).tolist() for k, v in self.buffers.items()},
                "confirmed": list(self.confirmed)}

    def initialize_state(self, state):
        self.delta = state["delta"]; self.ema = EMAFraudRate.restore(state["ema"])
        self.buffers = {k: deque([np.asarray(r, dtype=np.float32) for r in v], maxlen=self.L)
                        for k, v in state["buffers"].items()}
        self.confirmed = deque(state["confirmed"])
