"""Three-tier decision routing (Section 5.x): hold (s >= 0.95), review (delta <= s < 0.95), clear (s < delta).
Also emits WAIT for cold-start accounts with fewer than L prior transactions."""
from enum import Enum


class Decision(str, Enum):
    HOLD = "HOLD"
    REVIEW = "REVIEW"
    CLEAR = "CLEAR"
    WAIT = "WAIT"


def route(score: float, delta: float, hold_threshold: float = 0.95, cold_start: bool = False) -> Decision:
    if cold_start:
        return Decision.WAIT
    if score >= hold_threshold:
        return Decision.HOLD
    if score >= delta:
        return Decision.REVIEW
    return Decision.CLEAR
