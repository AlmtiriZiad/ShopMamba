"""Reference sketch of the Flink KeyedProcessFunction wrapping StreamingScorer.

Deployed as a PyFlink stateful operator keyed by account_id with exactly-once
checkpointing; kept here as documentation of the processElement / snapshotState /
initializeState contract described in Section 5.
"""
try:
    from pyflink.datastream import KeyedProcessFunction
except ImportError:      # PyFlink is optional for offline reproduction
    KeyedProcessFunction = object

from .streaming_infer import StreamingScorer


class ShopMambaOperator(KeyedProcessFunction):
    def __init__(self, model, L=512):
        self.scorer = StreamingScorer(model, L=L)
        self.state = None

    def open(self, runtime_context):
        # ValueState holding the serialised StreamingScorer snapshot per key
        from pyflink.datastream.state import ValueStateDescriptor
        from pyflink.common.typeinfo import Types
        self.state = runtime_context.get_state(ValueStateDescriptor("shopmamba", Types.PICKLED_BYTE_ARRAY()))

    def process_element(self, value, ctx):
        snap = self.state.value()
        if snap is not None:
            self.scorer.initialize_state(snap)
        account_id, feats, ts = value
        score, decision = self.scorer.process_element(account_id, feats, ts)
        self.state.update(self.scorer.snapshot_state())
        yield account_id, ts, score, decision.value
