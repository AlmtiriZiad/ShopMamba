"""Algorithm 1: single-run training entry point (Table 4 hyperparameters, seed 42).

    python -m shopmamba.training.train --dataset ieee-cis --config configs/model/shopmamba_mis.yaml
    python -m shopmamba.training.train --dataset ieee-cis --config configs/ablation/A2_no_tam.yaml
    python -m shopmamba.training.train --dataset ieee-cis --baseline LSTM

Writes checkpoint, validation-calibrated threshold delta, raw test scores and the
integer confusion matrix to results/logs/<run_name>/.
"""
import argparse
import json
from pathlib import Path

import numpy as np
import torch
import yaml
from torch.utils.data import DataLoader

from ..data.loaders import load_processed
from ..data.sequence_builder import make_windows
from ..models.shopmamba_mis import build_from_config
from ..baselines import LSTMBaseline, MambaAD, XGBoostFraud, REGISTRY
from ..utils.metrics import evaluate, calibrate_threshold
from ..utils.seeding import seed_everything

ROOT = Path(__file__).resolve().parents[3]


def build_model(args, cfg, d_in):
    if args.baseline is None:
        return build_from_config(cfg, d_in)
    if args.baseline == "LSTM":
        return LSTMBaseline(d_in)
    if args.baseline == "Mamba-AD":
        return MambaAD(d_in)
    if args.baseline == "XGBoost-Fraud":
        return XGBoostFraud(seed=args.seed)
    return REGISTRY[args.baseline](d_in, L=cfg["model"]["L"])


def scores_for(model, loader, device):
    ys, ss = [], []
    model.eval()
    with torch.no_grad():
        for x, y in loader:
            ss.append(model.score(x.to(device)).cpu()); ys.append(y)
    return torch.cat(ys).numpy(), torch.cat(ss).numpy()


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--dataset", required=True, choices=["ieee-cis", "paysim", "ulb"])
    ap.add_argument("--config", default="configs/model/shopmamba_mis.yaml")
    ap.add_argument("--baseline", default=None)
    ap.add_argument("--seed", type=int, default=42)
    ap.add_argument("--run_name", default=None)
    ap.add_argument("--eval_only", action="store_true")
    a = ap.parse_args()
    cfg = yaml.safe_load(open(ROOT / a.config))
    dcfg = yaml.safe_load(open(ROOT / "configs" / "datasets" / f"{a.dataset}.yaml"))
    seed_everything(a.seed)
    device = "cuda" if torch.cuda.is_available() else "cpu"

    df = load_processed(a.dataset)
    split = json.loads((ROOT / "data" / "splits" / f"{a.dataset}_split.json").read_text())
    L = cfg["model"]["L"]
    ds = {k: make_windows(df, split[k], L) for k in ("train", "val", "test")}
    d_in = ds["train"].X.shape[1]
    run = a.run_name or f"{a.baseline or Path(a.config).stem}_{a.dataset}_seed{a.seed}"
    out = ROOT / "results" / "logs" / run; out.mkdir(parents=True, exist_ok=True)
    model = build_model(a, cfg, d_in)

    if a.baseline == "XGBoost-Fraud":        # transaction-level, final-token features only
        Xtr = ds["train"].X[ds["train"].ends[:, -1]].numpy(); ytr = ds["train"].y[ds["train"].ends[:, -1]].numpy()
        Xva = ds["val"].X[ds["val"].ends[:, -1]].numpy(); yva = ds["val"].y[ds["val"].ends[:, -1]].numpy()
        Xte = ds["test"].X[ds["test"].ends[:, -1]].numpy(); yte = ds["test"].y[ds["test"].ends[:, -1]].numpy()
        model.fit(Xtr, ytr, Xva, yva)
        s_val, s_te = model.score(Xva), model.score(Xte)
    else:
        model.to(device)
        tr = cfg["train"]
        loader = {k: DataLoader(ds[k], batch_size=tr["batch_size"], shuffle=(k == "train"),
                                num_workers=4, drop_last=(k == "train")) for k in ds}
        if not a.eval_only:
            opt = torch.optim.AdamW(model.parameters(), lr=tr["lr"], weight_decay=tr.get("weight_decay", 0.01))
            if hasattr(model, "difs"):
                model.difs.pi.fill_(dcfg["fraud_rate"]); model.difs.initialised.fill_(True)
            for epoch in range(tr["epochs"]):
                model.train(); tot = 0.0
                for x, y in loader["train"]:
                    opt.zero_grad(); loss = model.loss(x.to(device), y.to(device)); loss.backward()
                    torch.nn.utils.clip_grad_norm_(model.parameters(), 1.0); opt.step(); tot += loss.item()
                g = model.difs.gamma().item() if hasattr(model, "difs") else float("nan")
                print(f"epoch {epoch + 1}/{tr['epochs']} loss {tot / len(loader['train']):.4f} gamma_t {g:.3f}", flush=True)
            torch.save({"model": model.state_dict(), "config": cfg}, out / "checkpoint.pt")
        else:
            model.load_state_dict(torch.load(out / "checkpoint.pt", map_location=device)["model"])
        yva, s_val = scores_for(model, loader["val"], device)
        if hasattr(model, "calibrate"):
            model.calibrate(torch.as_tensor(s_val)); yva, s_val = scores_for(model, loader["val"], device)
        yte, s_te = scores_for(model, loader["test"], device)

    delta = calibrate_threshold(yva, s_val, fpr_max=dcfg["fpr_max"])
    res = evaluate(yte, s_te, delta); res["delta"] = delta; res["cold_start_excluded"] = ds["test"].cold_start
    np.save(out / "test_scores.npy", s_te); np.save(out / "test_labels.npy", yte)
    (out / "metrics.json").write_text(json.dumps(res, indent=2))
    print(json.dumps(res, indent=2))


if __name__ == "__main__":
    main()
