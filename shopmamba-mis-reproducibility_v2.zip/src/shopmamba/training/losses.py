"""Loss functions used in Algorithm 1: DIFS dynamic focal loss (Eq. 31-32) + reconstruction (Eq. 19/33).
Provided as pure functions for unit testing; the model uses DIFS.focal_loss internally."""
import torch


def dynamic_focal_loss(logits, y, gamma, pi):
    p = torch.sigmoid(logits)
    p_t = torch.where(y > 0.5, p, 1 - p).clamp_min(1e-7)
    alpha = torch.where(y > 0.5, 1 - pi, pi)
    return (-alpha * (1 - p_t) ** gamma * torch.log(p_t)).mean()


def gamma_schedule(pi, gamma_min=0.5, gamma_max=5.0, pi_min=0.0002, pi_max=0.03):
    g = gamma_min + (gamma_max - gamma_min) * (pi_max - pi) / (pi_max - pi_min)
    return max(gamma_min, min(gamma_max, g))
