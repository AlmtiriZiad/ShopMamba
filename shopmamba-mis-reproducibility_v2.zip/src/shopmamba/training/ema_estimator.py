"""Streaming EMA fraud-rate estimator shared by training (per mini-batch, Eq. 29) and
streaming inference (delayed analyst-confirmed labels, 4-24 h cycle, Algorithm 2).
The state (pi, initialised) is serialised through snapshot()/restore() so that a Flink
snapshotState/initializeState pair can checkpoint it with exactly-once semantics.
"""
from dataclasses import dataclass


@dataclass
class EMAFraudRate:
    beta: float = 0.99
    pi: float = 0.0
    initialised: bool = False

    def update(self, batch_fraud_rate: float):
        if not self.initialised:
            self.pi, self.initialised = batch_fraud_rate, True
        else:
            self.pi = self.beta * self.pi + (1 - self.beta) * batch_fraud_rate
        return self.pi

    def snapshot(self):
        return {"beta": self.beta, "pi": self.pi, "initialised": self.initialised}

    @classmethod
    def restore(cls, state):
        return cls(**state)
