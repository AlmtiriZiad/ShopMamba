"""LSTM sequence baseline [4]: 2-layer LSTM (hidden 64) over the L-window, BCE loss."""
import torch
import torch.nn as nn
import torch.nn.functional as F


class LSTMBaseline(nn.Module):
    def __init__(self, d_in, hidden=64, layers=2):
        super().__init__()
        self.proj = nn.Linear(d_in, hidden)
        self.lstm = nn.LSTM(hidden, hidden, num_layers=layers, batch_first=True)
        self.head = nn.Linear(hidden, 1)

    def forward(self, x):
        h, _ = self.lstm(torch.relu(self.proj(x)))
        return self.head(h[:, -1]).squeeze(-1), None

    def score(self, x):
        return torch.sigmoid(self(x)[0])

    def loss(self, x, y):
        return F.binary_cross_entropy_with_logits(self(x)[0], y)
