"""Adapters for published baselines evaluated in Table 5.

The original authors' implementations are used unchanged; this module only wraps them
behind the common (score, loss) interface so experiments/run_main_results.sh can drive
them with the same splits, windows and threshold calibration. Install each package
with the pinned commit below before running; `make train` skips any baseline whose
import fails and records it in results/logs/skipped_baselines.txt.

    AnomalyTrans  [7]  Xu et al., ICLR 2022      pip install git+https://github.com/thuml/Anomaly-Transformer@main
    TranAD        [50] Tuli et al., VLDB 2022     pip install git+https://github.com/imperial-qore/TranAD@main
    DTCM          [8]  no public authors' repo as of this package's release. build_dtcm() tries
                       dtcm.model.DTCM first (set DTCM_REPO env var to a pip-installable URL if/when
                       one becomes available) and otherwise falls back to ReferenceDTCM below, a
                       capsule-encoder + transformer-decoder reimplementation from the architecture
                       description in [8] Section III. This fallback is NOT the original authors'
                       code and will not reproduce Table 5's DTCM numbers exactly -- it exists so the
                       pipeline runs end-to-end; treat DTCM rows regenerated this way as approximate.
    GTAN               no public authors' repo. build_gtan() tries gtan.model.GTAN first, else falls
                       back to ReferenceGTAN below, a single-hop graph-attention reimplementation.
                       Same caveat as DTCM: approximate, not the original code.
    DeepFraud          deep MLP fraud detector (reimplemented in this file, 3 x 256 ReLU, dropout 0.2)
    StreamML      [31] streaming ML (river-based incremental logistic regression + Hoeffding tree)

Each adapter exposes: build(d_in, **cfg) -> object with .fit_epoch(loader) and .score(x).

IMPORTANT: results/tables/table5_main_detection_performance.csv already contains the numbers
reported in the manuscript for every baseline, including DTCM and GTAN. You do NOT need to re-run
training to reproduce the paper's tables/figures -- analysis/verify_table_consistency.py and the
figures/ scripts consume that CSV directly. The adapters in this file are only needed if you want
to retrain a baseline from scratch (e.g. on new data), at which point the DTCM/GTAN caveat above
applies.
"""
import importlib

import torch
import torch.nn as nn
import torch.nn.functional as F

REGISTRY = {}


def register(name):
    def deco(fn):
        REGISTRY[name] = fn
        return fn
    return deco


class DeepFraud(nn.Module):
    def __init__(self, d_in, hidden=256, layers=3, dropout=0.2):
        super().__init__()
        mods, d = [], d_in
        for _ in range(layers):
            mods += [nn.Linear(d, hidden), nn.ReLU(), nn.Dropout(dropout)]
            d = hidden
        self.net = nn.Sequential(*mods, nn.Linear(hidden, 1))

    def forward(self, x):
        return self.net(x[:, -1]).squeeze(-1), None

    def score(self, x):
        return torch.sigmoid(self(x)[0])

    def loss(self, x, y):
        return F.binary_cross_entropy_with_logits(self(x)[0], y)


@register("DeepFraud")
def build_deepfraud(d_in, **cfg):
    return DeepFraud(d_in, **cfg)


def _optional(module, attr, name):
    try:
        return getattr(importlib.import_module(module), attr)
    except Exception as e:      # noqa: BLE001
        raise ImportError(f"{name} not installed: {e}. See baselines/external.py for the pinned source.")


class ReferenceDTCM(nn.Module):
    """Approximate reimplementation of [8]'s capsule-transformer mutual distillation encoder.

    NOT the original authors' code (no public repo was available at package release time).
    Architecture: a small capsule-style routing layer feeding a 2-layer transformer encoder,
    trained with a reconstruction objective, matching the reconstruction-based scoring used for
    every other autoencoder-style baseline in this package. Use only to keep the pipeline runnable
    end-to-end; do not expect exact reproduction of the DTCM row in Table 5 from this fallback.
    """
    def __init__(self, d_in, d_model=128, n_capsules=8, heads=4, layers=2, **_):
        super().__init__()
        self.capsule_proj = nn.Linear(d_in, n_capsules * (d_model // n_capsules))
        enc_layer = nn.TransformerEncoderLayer(d_model, heads, dim_feedforward=4 * d_model,
                                                batch_first=True)
        self.encoder = nn.TransformerEncoder(enc_layer, layers)
        self.decoder = nn.Linear(d_model, d_in)

    def forward(self, x):
        z = self.capsule_proj(x)
        z = self.encoder(z)
        recon = self.decoder(z)
        return recon, z

    def score(self, x):
        recon, _ = self(x)
        return ((recon - x) ** 2).mean(-1)

    def loss(self, x, y=None):
        recon, _ = self(x)
        return F.mse_loss(recon, x)


class ReferenceGTAN(nn.Module):
    """Approximate single-hop graph-attention reimplementation for the GTAN baseline.

    NOT the original authors' code. Treats each behavioral window as a fully-connected micro-graph
    over its L transactions and applies one graph-attention layer before a logit head, in place of
    the relational user-merchant graph used in the original paper. Fallback only -- see class
    docstring pattern in ReferenceDTCM above.
    """
    def __init__(self, d_in, d_model=128, heads=4, layers=2, **_):
        super().__init__()
        self.proj = nn.Linear(d_in, d_model)
        enc_layer = nn.TransformerEncoderLayer(d_model, heads, dim_feedforward=4 * d_model,
                                                batch_first=True)
        self.gat = nn.TransformerEncoder(enc_layer, layers)  # full attention == dense micro-graph
        self.head = nn.Linear(d_model, 1)

    def forward(self, x):
        z = self.gat(self.proj(x))
        return self.head(z[:, -1]).squeeze(-1)

    def score(self, x):
        return torch.sigmoid(self(x))

    def loss(self, x, y):
        return F.binary_cross_entropy_with_logits(self(x), y)


@register("AnomalyTrans")
def build_anomaly_trans(d_in, **cfg):
    from .wrappers import ReconstructionWrapper
    Model = _optional("model.AnomalyTransformer", "AnomalyTransformer", "AnomalyTrans")
    return ReconstructionWrapper(Model(win_size=cfg.get("L", 512), enc_in=d_in, c_out=d_in,
                                       e_layers=cfg.get("e_layers", 3)))


@register("TranAD")
def build_tranad(d_in, **cfg):
    from .wrappers import ReconstructionWrapper
    Model = _optional("src.models", "TranAD", "TranAD")
    return ReconstructionWrapper(Model(feats=d_in))


@register("DTCM")
def build_dtcm(d_in, **cfg):
    from .wrappers import ReconstructionWrapper
    try:
        Model = _optional("dtcm.model", "DTCM", "DTCM")
    except ImportError:
        import warnings
        warnings.warn("DTCM: no authors' repo found, falling back to ReferenceDTCM "
                       "(approximate, will not exactly reproduce Table 5). See external.py docstring.")
        Model = ReferenceDTCM
    return ReconstructionWrapper(Model(d_in, **cfg))


@register("GTAN")
def build_gtan(d_in, **cfg):
    from .wrappers import LogitWrapper
    try:
        Model = _optional("gtan.model", "GTAN", "GTAN")
    except ImportError:
        import warnings
        warnings.warn("GTAN: no authors' repo found, falling back to ReferenceGTAN "
                       "(approximate, will not exactly reproduce Table 5). See external.py docstring.")
        Model = ReferenceGTAN
    return LogitWrapper(Model(d_in, **cfg))


@register("StreamML")
def build_streamml(d_in, **cfg):
    from .wrappers import RiverWrapper
    return RiverWrapper(d_in, **cfg)
