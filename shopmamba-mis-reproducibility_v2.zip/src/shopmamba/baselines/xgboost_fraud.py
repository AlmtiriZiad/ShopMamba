"""XGBoost-Fraud baseline: transaction-level gradient-boosted trees, no sequence modelling.

Trained on the final-token features only (same test rows as the sequence models, cold-start
rows excluded identically). Hyperparameters fixed as in configs/model/baselines/xgboost_fraud.yaml.
"""
import numpy as np
import xgboost as xgb


class XGBoostFraud:
    def __init__(self, n_estimators=600, max_depth=8, learning_rate=0.05, subsample=0.8,
                 colsample_bytree=0.8, scale_pos_weight=None, seed=42):
        self.params = dict(n_estimators=n_estimators, max_depth=max_depth, learning_rate=learning_rate,
                           subsample=subsample, colsample_bytree=colsample_bytree,
                           scale_pos_weight=scale_pos_weight, random_state=seed, tree_method="hist",
                           n_jobs=2, eval_metric="aucpr")
        self.model = None

    def fit(self, X, y, X_val=None, y_val=None):
        p = dict(self.params)
        if p["scale_pos_weight"] is None:
            p["scale_pos_weight"] = float((y == 0).sum() / max(1, (y == 1).sum()))
        self.model = xgb.XGBClassifier(**p)
        self.model.fit(X, y, eval_set=[(X_val, y_val)] if X_val is not None else None, verbose=False)
        return self

    def score(self, X):
        return self.model.predict_proba(X)[:, 1]
