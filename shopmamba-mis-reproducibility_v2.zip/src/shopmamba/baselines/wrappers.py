"""Uniform (score, loss) interface around third-party baseline models."""
import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F


class ReconstructionWrapper(nn.Module):
    """Reconstruction-based detectors: score = normalised residual of the final token."""

    def __init__(self, model):
        super().__init__()
        self.model = model
        self.register_buffer("r_min", torch.tensor(0.0)); self.register_buffer("r_max", torch.tensor(1.0))

    def _residual(self, x):
        out = self.model(x)
        out = out[0] if isinstance(out, (tuple, list)) else out
        return ((x - out) ** 2).sum(-1)

    def forward(self, x):
        r = self._residual(x); return r[:, -1], r

    @torch.no_grad()
    def calibrate(self, residuals):
        self.r_min.copy_(residuals.min()); self.r_max.copy_(residuals.max())

    def score(self, x):
        r, _ = self(x); return ((r - self.r_min) / (self.r_max - self.r_min + 1e-9)).clamp(0, 1)

    def loss(self, x, y):
        _, r = self(x); return r[y < 0.5].mean() if (y < 0.5).any() else r.mean()


class LogitWrapper(nn.Module):
    def __init__(self, model):
        super().__init__(); self.model = model

    def forward(self, x):
        out = self.model(x); return (out[0] if isinstance(out, (tuple, list)) else out).squeeze(-1), None

    def score(self, x):
        return torch.sigmoid(self(x)[0])

    def loss(self, x, y):
        return F.binary_cross_entropy_with_logits(self(x)[0], y)


class RiverWrapper:
    """StreamML: incremental learner processing transactions one at a time (final-token features)."""

    def __init__(self, d_in, **cfg):
        from river import linear_model, preprocessing, tree, ensemble
        self.model = preprocessing.StandardScaler() | ensemble.VotingClassifier([
            linear_model.LogisticRegression(), tree.HoeffdingTreeClassifier()])

    def fit_epoch(self, loader):
        for x, y in loader:
            for xi, yi in zip(x[:, -1].numpy(), y.numpy()):
                self.model.learn_one(dict(enumerate(xi.tolist())), int(yi))

    def score(self, x):
        x = x[:, -1].numpy()
        return torch.tensor([self.model.predict_proba_one(dict(enumerate(xi.tolist()))).get(1, 0.0) for xi in x])
