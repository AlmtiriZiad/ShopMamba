"""Mamba-AD baseline [16]: bare selective SSM autoencoder scored by reconstruction residual.

No TAM and no DIFS; the anomaly score is the min-max normalised final-token residual and
the decision threshold is calibrated on the validation split exactly as for SHOPMAMBA-MIS.
Reuses the SSAE module so that the only difference from the full model is the removed
components (this is distinct from ablation A4, which additionally freezes selectivity).
"""
import torch
import torch.nn as nn

from ..models.ssae import SSAE


class MambaAD(nn.Module):
    def __init__(self, d_in, d_state=64, d_latent=64):
        super().__init__()
        self.ssae = SSAE(d_in, d_state, d_latent, selective=True)
        self.register_buffer("r_min", torch.tensor(0.0)); self.register_buffer("r_max", torch.tensor(1.0))

    def forward(self, x):
        _, _, r = self.ssae(x)
        return r[:, -1], r

    @torch.no_grad()
    def calibrate(self, residuals):
        self.r_min.copy_(residuals.min()); self.r_max.copy_(residuals.max())

    def score(self, x):
        r, _ = self(x)
        return ((r - self.r_min) / (self.r_max - self.r_min + 1e-9)).clamp(0, 1)

    def loss(self, x, y):
        _, r = self(x)
        return r[y < 0.5].mean() if (y < 0.5).any() else r.mean()   # unsupervised: reconstruct legitimate traffic
