# Data

None of the three datasets is redistributed. Download from Kaggle (account required),
place the files below under `data/raw/`, then run `make data`.

| Dataset | Source | Licence | Files | Rows |
|---|---|---|---|---|
| IECIS | https://www.kaggle.com/competitions/ieee-fraud-detection | competition rules | `ieee-cis/train_transaction.csv`, `ieee-cis/train_identity.csv` | 590,540 |
| PaySim | https://www.kaggle.com/datasets/ealaxi/paysim1 | CC BY-SA 4.0 | `paysim/PS_20174392719_1491204439457_log.csv` | 6,354,407 |
| ULB | https://www.kaggle.com/datasets/mlg-ulb/creditcardfraud | DbCL v1.0 | `ulb-creditcard/creditcard.csv` | 284,807 |

**IECIS: only the 590,540-row labelled training set is used.** The Kaggle competition
test set (`test_transaction.csv`, 506,691 rows, withheld labels) is not part of this
package and is not used anywhere in the paper. All IECIS numbers are on a chronological
held-out partition of the labelled data (114,209 rows, 3,997 positives, Section 6.1).

Preprocessing (`src/shopmamba/data/loaders.py`) produces one parquet per dataset with
`account_id`, `t`, `label` and `f_0 .. f_{d-1}` (d = 433 / 11 / 30). Categorical columns
are integer-coded; missing values are zero-filled. Row counts are asserted on load.
