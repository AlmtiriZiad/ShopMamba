import numpy as np, torch
from shopmamba.models import ShopMambaMIS
from shopmamba.inference.streaming_infer import StreamingScorer
from shopmamba.inference.decision_routing import Decision, route


def test_routing():
    assert route(0.99, 0.6) == Decision.HOLD and route(0.7, 0.6) == Decision.REVIEW
    assert route(0.1, 0.6) == Decision.CLEAR and route(0.99, 0.6, cold_start=True) == Decision.WAIT


def test_cold_start_then_score_and_checkpoint_roundtrip():
    m = ShopMambaMIS(d_in=5, d_state=4, d_latent=8, window=2)
    s = StreamingScorer(m, L=8, delta=0.5)
    for i in range(7):
        assert s.process_element("acc", np.random.randn(5), i)[1] == Decision.WAIT
    score, dec = s.process_element("acc", np.random.randn(5), 7)
    assert score is not None and dec != Decision.WAIT
    snap = s.snapshot_state(); s2 = StreamingScorer(m, L=8); s2.initialize_state(snap)
    assert len(s2.buffers["acc"]) == 8 and s2.delta == s.delta
    assert m.difs.frozen is True
