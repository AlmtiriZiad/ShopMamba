import torch
from shopmamba.models import ShopMambaMIS, SSAE, TAM, DIFS


def test_ssae_shapes():
    m = SSAE(d_in=11, d_state=8, d_latent=16)
    z, x_hat, r = m(torch.randn(2, 32, 11))
    assert z.shape == (2, 32, 16) and x_hat.shape == (2, 32, 11) and r.shape == (2, 32)


def test_tam_is_causal():
    tam = TAM(16, window=4); z = torch.randn(1, 20, 16)
    out1, w = tam(z, return_weights=True)
    z2 = z.clone(); z2[0, 15:] += 10.0                      # perturb the future
    out2 = tam(z2)
    assert torch.allclose(out1[0, :15], out2[0, :15], atol=1e-5)
    assert w.shape == (1, 20, 4)


def test_difs_gamma_clipping_iecis_and_paysim():
    d = DIFS(pi_init=0.035); assert float(d.gamma()) == 0.5          # IECIS: pi > pi_max -> gamma_min
    d = DIFS(pi_init=0.0013); g = float(d.gamma())
    assert 0.5 < g < 5.0 and abs(g - (0.5 + 4.5 * (0.03 - 0.0013) / (0.03 - 0.0002))) < 1e-6
    d = DIFS(pi_init=0.0001); assert float(d.gamma()) == 5.0         # below pi_min -> gamma_max


def test_full_model_forward_and_loss():
    m = ShopMambaMIS(d_in=11, d_state=8, d_latent=16, window=4)
    x = torch.randn(4, 32, 11); y = torch.tensor([0., 1., 0., 0.])
    loss = m.loss(x, y); loss.backward()
    assert loss.ndim == 0 and torch.isfinite(loss) and m.score(x).shape == (4,)


def test_ablation_variants_build():
    for kw in (dict(selective=False), dict(use_tam=False), dict(static_gamma=2.0)):
        ShopMambaMIS(d_in=5, d_state=4, d_latent=8, window=2, **kw).score(torch.randn(1, 8, 5))
