import numpy as np
from shopmamba.utils.metrics import confusion, from_confusion, evaluate, calibrate_threshold


def test_from_confusion_matches_table6_shopmamba_iecis():
    m = from_confusion(tp=3913, fp=129, fn=84, tn=110083)
    assert round(m["precision"], 3) == 0.968 and round(m["recall"], 3) == 0.979
    assert abs(m["f1"] - 0.973) < 0.001 and round(100 * m["fpr"], 2) == 0.12


def test_ulb_recall_is_integer_ratio():
    m = from_confusion(tp=48, fp=1, fn=1, tn=28431)
    assert round(m["recall"], 3) == 0.980 and round(m["precision"], 3) == 0.980


def test_confusion_counts():
    y = np.array([1, 1, 0, 0, 1]); p = np.array([1, 0, 0, 1, 1])
    assert confusion(y, p) == dict(tp=2, fp=1, fn=1, tn=1)


def test_threshold_respects_fpr_cap():
    rng = np.random.default_rng(0); y = (rng.random(5000) < 0.02).astype(int)
    s = np.clip(rng.normal(0.2, 0.15, 5000) + 0.5 * y, 0, 1)
    d = calibrate_threshold(y, s, fpr_max=0.005)
    assert evaluate(y, s, d)["fpr"] <= 0.005
