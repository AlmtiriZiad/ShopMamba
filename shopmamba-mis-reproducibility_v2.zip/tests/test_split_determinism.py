import json
from pathlib import Path
import numpy as np, pandas as pd, pytest
from shopmamba.data.chronological_split import make_split, check_sizes, SPLITS

ROOT = Path(__file__).resolve().parents[1]
EXP = json.loads((SPLITS / "expected_sizes.json").read_text())


def test_expected_sizes_match_table3():
    t3 = pd.read_csv(ROOT / "results/tables/table3_dataset_specs.csv").set_index("dataset")
    for name, key in (("ieee-cis", "IECIS"), ("paysim", "PaySim"), ("ulb", "ULB")):
        assert EXP[name]["test_rows"] == t3.loc[key, "test_rows"]
        assert EXP[name]["test_positives"] == t3.loc[key, "test_positives"]


def test_split_is_chronological_and_disjoint():
    df = pd.DataFrame({"t": np.arange(1000), "label": 0})
    s = make_split("paysim", df)
    assert len(s["train"]) == 700 and len(s["val"]) == 150 and len(s["test"]) == 150
    assert max(s["train"]) < min(s["val"]) < max(s["val"]) < min(s["test"])


@pytest.mark.requires_data
def test_real_split_sizes():
    from shopmamba.data.chronological_split import build
    for n in ("ieee-cis", "paysim", "ulb"):
        build(n)
