"""Automated version of analysis/verify_table_consistency.py (runs in CI without data)."""
import subprocess, sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


def test_tables_consistent():
    r = subprocess.run([sys.executable, str(ROOT / "analysis/verify_table_consistency.py"), "--strict"], capture_output=True, text=True)
    assert r.returncode == 0, r.stdout
