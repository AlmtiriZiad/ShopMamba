"""Figure 9: median latency vs sequence length L. Reads results/tables/figure9_latency_vs_seqlen.tsv
(produced by experiments/run_latency_sweep.sh) plus baseline sweeps if present."""
import os, glob
import matplotlib; matplotlib.use("Agg")
import matplotlib.pyplot as plt
import pandas as pd
from pathlib import Path

plt.rcParams.update({"font.family": "serif", "font.serif": ["Times New Roman", "Liberation Serif"], "font.size": 9})
TAB = Path(__file__).resolve().parents[1] / "results/tables"
fig, ax = plt.subplots(figsize=(4.2, 2.8))
for f in sorted(glob.glob(str(TAB / "figure9_latency_vs_seqlen*.tsv"))):
    d = pd.read_csv(f, sep="\t", header=None, names=["L", "ms"])
    d["L"] = d.L.str.replace("L=", "").astype(int); d["ms"] = d.ms.str.replace("median_ms=", "").astype(float)
    ax.plot(d.L, d.ms, marker="o", ms=3, label=Path(f).stem.replace("figure9_latency_vs_seqlen", "").strip("_") or "SHOPMAMBA-MIS")
ax.axhline(5.0, color="red", linestyle="--", linewidth=0.8, label="5 ms SLA")
ax.set_xscale("log", base=2); ax.set_xlabel("Sequence length L"); ax.set_ylabel("Median latency (ms)")
ax.legend(frameon=False, fontsize=7); ax.spines[["top", "right"]].set_visible(False); fig.tight_layout()
out = os.path.join(os.path.expanduser("~"), "Downloads", "SHOPMAMBA-MIS"); os.makedirs(out, exist_ok=True)
fig.savefig(os.path.join(out, "fig9_latency_vs_seqlen.png"), dpi=600); print("saved", out)
