"""Figure 8: F1 scores of all methods on IECIS, PaySim and ULB (Table 5)."""
import os
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

plt.rcParams.update({"font.family": "serif",
                     "font.serif": ["Times New Roman", "Liberation Serif", "DejaVu Serif"],
                     "font.size": 9, "axes.linewidth": 0.8})

methods = ["LSTM", "AnomalyTrans", "DTCM", "TranAD", "DeepFraud", "GTAN",
           "StreamML", "XGBoost-Fraud", "Mamba-AD", "SHOPMAMBA-MIS"]
f1 = {  # Table 5, seed = 42
    "IECIS":  [0.901, 0.923, 0.918, 0.931, 0.897, 0.914, 0.919, 0.887, 0.941, 0.973],
    "PaySim": [0.832, 0.851, 0.848, 0.861, 0.842, 0.847, 0.863, 0.836, 0.868, 0.920],
    "ULB":    [0.918, 0.929, 0.929, 0.939, 0.909, 0.929, 0.929, 0.909, 0.949, 0.980],
}
colors = {"IECIS": "#1f4e79", "PaySim": "#c0504d", "ULB": "#4e9a51"}

x = np.arange(len(methods)); w = 0.26
fig, ax = plt.subplots(figsize=(7.2, 3.2))
for k, (ds, vals) in enumerate(f1.items()):
    bars = ax.bar(x + (k - 1) * w, vals, w, label=ds, color=colors[ds],
                  edgecolor="black", linewidth=0.4)
    for b, v in zip(bars, vals):
        ax.text(b.get_x() + b.get_width() / 2, v + 0.004, f"{v:.3f}",
                ha="center", va="bottom", fontsize=5.2, rotation=90)
ax.axvspan(x[-1] - 0.45, x[-1] + 0.45, color="#dfe8f5", alpha=0.6, zorder=0)
ax.set_ylim(0.80, 1.02); ax.set_ylabel("F1 score")
ax.set_xticks(x); ax.set_xticklabels(methods, rotation=25, ha="right")
ax.yaxis.grid(True, linestyle="--", linewidth=0.4, alpha=0.6); ax.set_axisbelow(True)
ax.spines[["top", "right"]].set_visible(False)
ax.legend(ncol=3, loc="upper left", frameon=False, fontsize=8)
fig.tight_layout()
out = os.path.join(os.path.expanduser("~"), "Downloads", "SHOPMAMBA-MIS")
os.makedirs(out, exist_ok=True)
fig.savefig(os.path.join(out, "fig8_f1_by_dataset.png"), dpi=600)
fig.savefig(os.path.join(out, "fig8_f1_by_dataset.pdf"))
print("saved to", out)
