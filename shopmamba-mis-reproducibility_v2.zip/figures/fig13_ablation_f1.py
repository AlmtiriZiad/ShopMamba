"""Figure 13: ablation F1 on IECIS (Table 7). IEEE style, Times New Roman, 600 dpi."""
import os
import matplotlib; matplotlib.use("Agg")
import matplotlib.pyplot as plt
import pandas as pd
from pathlib import Path

plt.rcParams.update({"font.family": "serif", "font.serif": ["Times New Roman", "Liberation Serif"], "font.size": 9})
t7 = pd.read_csv(Path(__file__).resolve().parents[1] / "results/tables/table7_ablation_iecis.csv")
fig, ax = plt.subplots(figsize=(4.2, 2.8))
bars = ax.bar(range(len(t7)), t7.f1, color=["#1f4e79"] + ["#8c8c8c"] * (len(t7) - 1), edgecolor="black", linewidth=0.4)
for b, f, d in zip(bars, t7.f1, t7.delta_f1_pp):
    ax.text(b.get_x() + b.get_width() / 2, f + 0.002, f"{f:.3f}" + ("" if d == 0 else f"\n({d:+.1f} pp)"), ha="center", va="bottom", fontsize=6.5)
ax.set_xticks(range(len(t7))); ax.set_xticklabels([v.split(":")[0] if ":" in v else "Full" for v in t7.variant])
ax.set_ylim(0.88, 0.99); ax.set_ylabel("F1 (IECIS)"); ax.spines[["top", "right"]].set_visible(False)
ax.yaxis.grid(True, linestyle="--", linewidth=0.4, alpha=0.6); ax.set_axisbelow(True)
fig.tight_layout()
out = os.path.join(os.path.expanduser("~"), "Downloads", "SHOPMAMBA-MIS"); os.makedirs(out, exist_ok=True)
fig.savefig(os.path.join(out, "fig13_ablation_f1.png"), dpi=600); print("saved", out)
