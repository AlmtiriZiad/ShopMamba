# SHOPMAMBA-MIS Reproducibility Package

Code, configurations, splits and result tables for the manuscript

> **A Selective State-Space Model for Real-Time E-Commerce Transaction Anomaly Detection in Management Information Systems** (SHOPMAMBA-MIS), submitted to *Journal of Theoretical and Applied Electronic Commerce Research* (JTAER).

Every folder maps to a table, figure or claim in the paper so that any reported number can be regenerated or checked.

## What is in this repository

| Path | Reproduces |
|---|---|
| `src/shopmamba/models/` | SSAE (Eq. 14 to 19), TAM (Eq. 20 to 26), DIFS (Eq. 27 to 33), full model |
| `src/shopmamba/baselines/` | LSTM, XGBoost-Fraud, Mamba-AD reference implementations; adapters for TranAD, AnomalyTrans, DTCM, GTAN, DeepFraud, StreamML |
| `src/shopmamba/data/` | Loaders, chronological splits (Table 3), sequence construction (Section 6.1, L = 512) |
| `src/shopmamba/training/train.py` | Algorithm 1 training loop (Table 4 hyperparameters, seed 42) |
| `src/shopmamba/inference/` | Algorithm 2 streaming inference, frozen EMA, three-tier decision routing |
| `experiments/*.sh` | Table 5, Table 6, Table 7, Figure 8, Figure 9, Figure 13 |
| `results/tables/*.csv` | Tables 3 to 8 exactly as printed in the revised manuscript |
| `analysis/verify_table_consistency.py` | CI gate: recomputes Precision, Recall, F1, FPR, MCC from Table 6 integers and checks Table 5 and Table 7 |
| `analysis/business_scenario_calc.py` | Table 8 scenario arithmetic |
| `figures/fig8_f1_by_dataset.py` | Figure 8 (Times New Roman, 600 dpi) |
| `tests/` | Unit tests for metrics, splits, model shapes, table consistency |
| `docs/` | Step-by-step reproduction guides and known limitations |

## Quick start

```bash
conda env create -f environment.yml && conda activate shopmamba
make verify           # checks every number in results/tables against Table 6 integers (no data needed)
make data             # download + preprocess the three Kaggle datasets (see data/README.md)
make train            # trains SHOPMAMBA-MIS on IECIS, PaySim, ULB (seed 42)
make eval             # regenerates Table 5 / Table 6 CSVs from raw predictions
make ablation         # regenerates Table 7 (A1 to A4 on IECIS)
make figures          # Figure 8, 9, 13
```

`make verify` runs in seconds and requires no data; it is also executed by GitHub Actions on every push (`.github/workflows/ci.yml`).

## Hardware and software used in the paper

| Item | Value |
|---|---|
| Framework | PyTorch 2.2.1, CUDA 12.1 |
| Training GPU | NVIDIA A100 80 GB |
| Inference CPU | Intel Xeon E5-2690 v4 (2 cores allocated), 16 GB RAM |
| Optimizer | AdamW, learning rate 3e-4, batch 256, 50 epochs |
| Model | N = 64, M = 64, L = 512, W = 16, beta = 0.99, gamma in [0.5, 5.0], lambda = 0.3 |
| Seed | 42 (single run, see `docs/KNOWN_LIMITATIONS.md`) |

## Datasets

All three datasets are public Kaggle datasets and are **not** redistributed here. `data/README.md` gives the URLs, licences, expected file names, MD5 checksums of the preprocessed parquet files and the exact chronological split sizes (IECIS test 114,209 rows / 3,997 positives; PaySim test 953,161 / 1,239; ULB test 28,481 / 49).

## Citation

See `CITATION.cff`.

## Licence

MIT (code). Datasets retain their original Kaggle licences.
