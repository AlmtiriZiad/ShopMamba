#!/usr/bin/env python
"""CI gate: every metric in Table 5 must be reconstructible from its Table 6 integers.

Checks
  1. Precision, Recall, F1, FPR and MCC recomputed from (TP, FP, FN, TN) in
     results/tables/table6_confusion_matrices.csv agree with
     results/tables/table5_main_detection_performance.csv within one unit of the
     last printed digit (0.001 for ratios; 0.005 / 0.0005 for FPR percent).
  2. Test-set sizes implied by Table 6 (TP+FN positives, TP+FP+FN+TN rows) equal
     the sizes stated in Table 3 for every method on every dataset.
  3. The full-model row of Table 7 (F1, FPR) equals the SHOPMAMBA-MIS IECIS row
     of Table 5, and every ablation delta_f1 equals f1 - full f1.
  4. Optional cross-check of headline text claims (--claims) such as
     "TAM reduces FPR from 0.19% to 0.12% (37% relative)".
  5. The number of distinct baseline methods (excluding SHOPMAMBA-MIS) in Table 5,
     Table 6 and Table 1 equals EXPECTED_BASELINE_COUNT below. This catches drift
     like a stale "six baselines" sentence in the manuscript prose after a baseline
     is added to the tables but not to every narrative mention of the count.

Exit code 1 on any mismatch so the GitHub Actions workflow fails.
"""
import argparse
import math
import sys
from pathlib import Path

import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
TAB = ROOT / "results" / "tables"


def metrics_from_counts(tp, fp, fn, tn):
    prec = tp / (tp + fp) if tp + fp else 0.0
    rec = tp / (tp + fn) if tp + fn else 0.0
    f1 = 2 * prec * rec / (prec + rec) if prec + rec else 0.0
    fpr = fp / (fp + tn) if fp + tn else 0.0
    den = math.sqrt((tp + fp) * (tp + fn) * (tn + fp) * (tn + fn))
    mcc = (tp * tn - fp * fn) / den if den else 0.0
    return dict(precision=prec, recall=rec, f1=f1, fpr_pct=100 * fpr, mcc=mcc)


def fpr_tol(printed):
    """Table 5 prints FPR with 2 decimals when >= 0.1 % and 3 decimals below."""
    return 0.005 if printed >= 0.1 else 0.0005


def check_table5(strict):
    t5 = pd.read_csv(TAB / "table5_main_detection_performance.csv")
    t6 = pd.read_csv(TAB / "table6_confusion_matrices.csv")
    t3 = pd.read_csv(TAB / "table3_dataset_specs.csv").set_index("dataset")
    m = t5.merge(t6, on=["method", "dataset"], how="outer", indicator=True)
    errors = []
    if (m["_merge"] != "both").any():
        errors.append("Table 5 and Table 6 do not list the same (method, dataset) rows")
    for _, r in m.iterrows():
        calc = metrics_from_counts(r.tp, r.fp, r.fn, r.tn)
        for k, tol in (("precision", 0.001), ("recall", 0.001), ("f1", 0.001)):
            if abs(calc[k] - r[k]) > tol:
                errors.append(f"{r.method}/{r.dataset}: {k} printed {r[k]:.3f}, integers give {calc[k]:.4f}")
        if abs(calc["fpr_pct"] - r.fpr_pct) > fpr_tol(r.fpr_pct):
            errors.append(f"{r.method}/{r.dataset}: FPR printed {r.fpr_pct}%, integers give {calc['fpr_pct']:.4f}%")
        # MCC is stated in the paper as directly evaluated; warn beyond 0.002, fail beyond 0.01
        d = abs(calc["mcc"] - r.mcc)
        if d > 0.01 or (strict and d > 0.002):
            errors.append(f"{r.method}/{r.dataset}: MCC printed {r.mcc:.3f}, integers give {calc['mcc']:.4f}")
        rows, pos = r.tp + r.fp + r.fn + r.tn, r.tp + r.fn
        if rows != t3.loc[r.dataset, "test_rows"] or pos != t3.loc[r.dataset, "test_positives"]:
            errors.append(f"{r.method}/{r.dataset}: Table 6 implies {rows} rows / {pos} positives, "
                          f"Table 3 states {t3.loc[r.dataset, 'test_rows']} / {t3.loc[r.dataset, 'test_positives']}")
    return errors


def check_table7():
    t5 = pd.read_csv(TAB / "table5_main_detection_performance.csv")
    t7 = pd.read_csv(TAB / "table7_ablation_iecis.csv")
    full5 = t5[(t5.method == "SHOPMAMBA-MIS") & (t5.dataset == "IECIS")].iloc[0]
    full7 = t7.iloc[0]
    errors = []
    if abs(full5.f1 - full7.f1) > 1e-9:
        errors.append(f"Table 7 full-model F1 {full7.f1} != Table 5 {full5.f1}")
    if abs(full5.fpr_pct - full7.fpr_pct) > 1e-9:
        errors.append(f"Table 7 full-model FPR {full7.fpr_pct}% != Table 5 {full5.fpr_pct}%")
    for _, r in t7.iloc[1:].iterrows():
        d = round((r.f1 - full7.f1) * 100, 1)
        if abs(d - r.delta_f1_pp) > 0.05:
            errors.append(f"Table 7 {r.variant}: delta printed {r.delta_f1_pp}, recomputed {d}")
        if r.fpr_pct <= full7.fpr_pct:
            errors.append(f"Table 7 {r.variant}: FPR {r.fpr_pct}% not worse than full model")
    return errors


EXPECTED_BASELINE_COUNT = 9  # LSTM, AnomalyTrans, DTCM, TranAD, DeepFraud, GTAN, StreamML,
                             # XGBoost-Fraud, Mamba-AD (SHOPMAMBA-MIS is the proposed method,
                             # not a baseline). Keep this in sync with any manuscript sentence
                             # that states a baseline count in prose -- see
                             # docs/MANUSCRIPT_TEXT_SYNC.md for the exact locations that must
                             # agree with this number (this script cannot parse the .docx text
                             # itself, so those sentences are checked by a human against this
                             # constant, not recomputed automatically).


def check_baseline_count():
    t5 = pd.read_csv(TAB / "table5_main_detection_performance.csv")
    t6 = pd.read_csv(TAB / "table6_confusion_matrices.csv")
    errors = []
    for name, df in (("Table 5", t5), ("Table 6", t6)):
        methods = set(df.method) - {"SHOPMAMBA-MIS"}
        if len(methods) != EXPECTED_BASELINE_COUNT:
            errors.append(f"{name} lists {len(methods)} baselines (excl. SHOPMAMBA-MIS), "
                           f"expected {EXPECTED_BASELINE_COUNT}: {sorted(methods)}")
    t1 = pd.read_csv(TAB / "table1_capability_comparison.csv")
    t1_baselines = t1[~t1.method.isin(["SHOPMAMBA-MIS"])]
    if len(t1_baselines) < EXPECTED_BASELINE_COUNT:
        errors.append(f"Table 1 lists only {len(t1_baselines)} non-proposed methods, "
                       f"fewer than the {EXPECTED_BASELINE_COUNT} baselines evaluated in Table 5")
    return errors


def check_claims():
    """Numbers quoted in Contribution C3, Section 6.7 (H2) and the Conclusion."""
    t7 = pd.read_csv(TAB / "table7_ablation_iecis.csv").set_index("variant")
    full, a2 = t7.loc["SHOPMAMBA-MIS (full)"], t7.loc["A2: no TAM"]
    rel = (a2.fpr_pct - full.fpr_pct) / a2.fpr_pct * 100
    absd = a2.fpr_pct - full.fpr_pct
    errors = []
    if round(rel) != 37:
        errors.append(f"C3/Conclusion claim '37% relative FPR reduction' recomputes to {rel:.1f}%")
    if abs(absd - 0.07) > 0.005:
        errors.append(f"H2 claim '0.07 percentage points' recomputes to {absd:.3f}")
    t5 = pd.read_csv(TAB / "table5_main_detection_performance.csv")
    for ds, claimed in (("IECIS", 4.2), ("PaySim", 5.9), ("ULB", 4.1)):
        sub = t5[t5.dataset == ds].set_index("method")
        gain = round((sub.loc["SHOPMAMBA-MIS", "f1"] - sub.loc["TranAD", "f1"]) * 100, 1)
        if abs(gain - claimed) > 0.05:
            errors.append(f"Abstract/C5 claim '+{claimed} pp on {ds}' recomputes to {gain} pp")
    return errors


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--strict", action="store_true", help="tight MCC tolerance (0.002)")
    ap.add_argument("--no-claims", action="store_true")
    a = ap.parse_args()
    errors = check_table5(a.strict) + check_table7() + check_baseline_count()
    if not a.no_claims:
        errors += check_claims()
    if errors:
        print("TABLE CONSISTENCY CHECK FAILED")
        for e in errors:
            print("  -", e)
        sys.exit(1)
    print("Table 5, Table 6, Table 7 and text claims are mutually consistent.")


if __name__ == "__main__":
    main()
