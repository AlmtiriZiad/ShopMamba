#!/usr/bin/env python
"""Figure 11 support: precision-recall curve and AUPRC on a dataset from saved raw scores."""
import argparse
from pathlib import Path
import numpy as np, pandas as pd
from sklearn.metrics import precision_recall_curve, average_precision_score

ROOT = Path(__file__).resolve().parents[1]

def main():
    ap = argparse.ArgumentParser(); ap.add_argument("--dataset", default="ulb"); a = ap.parse_args()
    rows = []
    for run_dir in sorted((ROOT / "results/logs").glob(f"*_{a.dataset}_seed42")):
        s, y = np.load(run_dir / "test_scores.npy"), np.load(run_dir / "test_labels.npy")
        p, r, _ = precision_recall_curve(y, s)
        rows += [dict(run=run_dir.name, precision=pi, recall=ri) for pi, ri in zip(p, r)]
        print(run_dir.name, "AUPRC", round(average_precision_score(y, s), 3))
    pd.DataFrame(rows).to_csv(ROOT / f"results/tables/figure11_pr_curves_{a.dataset}.csv", index=False)

if __name__ == "__main__":
    main()
