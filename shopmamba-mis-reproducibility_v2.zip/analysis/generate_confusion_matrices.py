#!/usr/bin/env python
"""Regenerates Table 6 (raw TP/FP/FN/TN) and Table 5 FROM raw saved predictions, never by
back-deriving from printed metrics. Reads results/logs/<run>/metrics.json written by train.py
and rewrites results/tables/table5_*.csv and table6_*.csv; then the CI gate re-checks them."""
import argparse
import json
from pathlib import Path

import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
LOGS, TAB = ROOT / "results" / "logs", ROOT / "results" / "tables"
METHODS = ["LSTM", "AnomalyTrans", "DTCM", "TranAD", "DeepFraud", "GTAN", "StreamML", "XGBoost-Fraud", "Mamba-AD"]
DS = {"ieee-cis": "IECIS", "paysim": "PaySim", "ulb": "ULB"}


def load(run):
    p = LOGS / run / "metrics.json"
    return json.loads(p.read_text()) if p.exists() else None


def main():
    ap = argparse.ArgumentParser(); ap.add_argument("--ablation", action="store_true"); a = ap.parse_args()
    if a.ablation:
        rows = []
        for var, run in [("SHOPMAMBA-MIS (full)", "shopmamba_mis_ieee-cis_seed42"), ("A1: no selectivity", "A1_no_selectivity_ieee-cis_seed42"),
                         ("A2: no TAM", "A2_no_tam_ieee-cis_seed42"), ("A3: static focal", "A3_static_focal_ieee-cis_seed42"),
                         ("A4: A1+A2+A3 (plain SSM)", "A4_plain_ssm_ieee-cis_seed42")]:
            m = load(run)
            if m:
                rows.append(dict(variant=var, f1=round(m["f1"], 3), fpr_pct=round(100 * m["fpr"], 2)))
        full = rows[0]["f1"]
        for r in rows:
            r["delta_f1_pp"] = round((r["f1"] - full) * 100, 1)
        pd.DataFrame(rows).to_csv(TAB / "table7_ablation_iecis.regenerated.csv", index=False)
        print(pd.DataFrame(rows)); return
    t5, t6 = [], []
    for ds, DSN in DS.items():
        for meth in METHODS + ["SHOPMAMBA-MIS"]:
            run = f"{'shopmamba_mis' if meth == 'SHOPMAMBA-MIS' else meth}_{ds}_seed42"
            m = load(run)
            if not m:
                print("missing", run); continue
            t5.append(dict(method=meth, dataset=DSN, f1=round(m["f1"], 3), precision=round(m["precision"], 3),
                           recall=round(m["recall"], 3), auroc=round(m["auroc"], 3), auprc=round(m["auprc"], 3),
                           fpr_pct=round(100 * m["fpr"], 3), mcc=round(m["mcc"], 3)))
            t6.append(dict(method=meth, dataset=DSN, tp=m["tp"], fp=m["fp"], fn=m["fn"], tn=m["tn"]))
    pd.DataFrame(t5).to_csv(TAB / "table5_main_detection_performance.regenerated.csv", index=False)
    pd.DataFrame(t6).to_csv(TAB / "table6_confusion_matrices.regenerated.csv", index=False)
    print(f"wrote {len(t5)} rows; diff against committed tables with `git diff` then run analysis/verify_table_consistency.py")


if __name__ == "__main__":
    main()
