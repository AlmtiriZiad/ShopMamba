#!/usr/bin/env python
"""Figure 10 support: hourly F1 over a 24 h PaySim window for DIFS vs static focal runs.
Reads saved test scores/labels and the test split's `step` field (1 step = 1 hour in PaySim)."""
import argparse, json
from pathlib import Path
import numpy as np, pandas as pd
from shopmamba.data.loaders import load_processed
from shopmamba.utils.metrics import evaluate

ROOT = Path(__file__).resolve().parents[1]

def main():
    ap = argparse.ArgumentParser(); ap.add_argument("--runs", nargs="+", required=True); ap.add_argument("--hours", type=int, default=24)
    a = ap.parse_args()
    df = load_processed("paysim"); split = json.loads((ROOT / "data/splits/paysim_split.json").read_text())
    steps = df.iloc[split["test"]]["t"].values[511:]           # windows start after the first L-1 rows
    out = []
    for run in a.runs:
        s = np.load(ROOT / f"results/logs/{run}/test_scores.npy"); y = np.load(ROOT / f"results/logs/{run}/test_labels.npy")
        delta = json.loads((ROOT / f"results/logs/{run}/metrics.json").read_text())["delta"]
        for h in range(a.hours):
            m = steps[:len(s)] == steps.min() + h
            if m.sum() and y[m].sum():
                r = evaluate(y[m], s[m], delta); out.append(dict(run=run, hour=h, f1=r["f1"], fraud_rate=y[m].mean()))
    pd.DataFrame(out).to_csv(ROOT / "results/tables/figure10_difs_drift.csv", index=False); print(pd.DataFrame(out))

if __name__ == "__main__":
    main()
