#!/usr/bin/env python
"""Multi-seed replication + paired Wilcoxon test (identified as future work in Section 6.12).
Not run for the submitted results (single seed 42). Usage once multi-seed logs exist:
    python analysis/statistical_significance.py --seeds 42 43 44 45 46 --dataset ieee-cis --baseline TranAD"""
import argparse, json
from pathlib import Path
import numpy as np
from scipy.stats import wilcoxon

ROOT = Path(__file__).resolve().parents[1]

def f1s(prefix, ds, seeds):
    return [json.loads((ROOT / f"results/logs/{prefix}_{ds}_seed{s}/metrics.json").read_text())["f1"] for s in seeds]

if __name__ == "__main__":
    ap = argparse.ArgumentParser(); ap.add_argument("--seeds", nargs="+", type=int, required=True)
    ap.add_argument("--dataset", required=True); ap.add_argument("--baseline", default="TranAD"); a = ap.parse_args()
    ours, base = f1s("shopmamba_mis", a.dataset, a.seeds), f1s(a.baseline, a.dataset, a.seeds)
    print(f"SHOPMAMBA-MIS F1 {np.mean(ours):.4f} ± {np.std(ours):.4f}; {a.baseline} {np.mean(base):.4f} ± {np.std(base):.4f}")
    print("paired Wilcoxon p =", wilcoxon(ours, base).pvalue)
