#!/usr/bin/env python
"""Table 8: illustrative, scenario-based organisational value estimates.

Assumptions (stated in the Table 8 caption): daily volume = 590,540 transactions used as a
scenario input, investigation cost = $25 per alert, average fraud value = $150, 365 days.
Inputs are the IECIS Table 6 integers for TranAD and SHOPMAMBA-MIS. These are NOT live
measurements; the script exists so every printed dollar figure is traceable to its formula.
"""
import pandas as pd
from pathlib import Path

TAB = Path(__file__).resolve().parents[1] / "results" / "tables"
COST_PER_ALERT, FRAUD_VALUE, DAILY_VOLUME, DAYS = 25.0, 150.0, 590_540, 365
TEST_ROWS, TEST_POS = 114_209, 3_997
PENALTY_AVOIDANCE = 5.0e6            # scenario assumption, Table 8 row 6


def main():
    t6 = pd.read_csv(TAB / "table6_confusion_matrices.csv").set_index(["method", "dataset"])
    tr, sm = t6.loc[("TranAD", "IECIS")], t6.loc[("SHOPMAMBA-MIS", "IECIS")]
    scale = DAILY_VOLUME / TEST_ROWS                      # scale test-partition counts to a scenario day
    fa_tr, fa_sm = int(tr.fp), int(sm.fp)                 # false alerts/day as printed (partition counts used directly)
    daily_pos = round(TEST_POS * scale)                   # 20,669 fraud events per scenario day
    caught_tr, caught_sm = round(tr.tp * scale), round(sm.tp * scale)
    inv_saving_day = (fa_tr - fa_sm) * COST_PER_ALERT
    rows = [
        ("False alerts per day (IECIS)", fa_tr, fa_sm, f"{100 * (fa_sm - fa_tr) / fa_tr:+.1f}%"),
        ("Investigation cost per day", f"${fa_tr * COST_PER_ALERT:,.0f}", f"${fa_sm * COST_PER_ALERT:,.0f}", f"-${inv_saving_day:,.0f}"),
        ("Annualized investigation saving", "", f"${inv_saving_day * DAYS / 1e6:.2f}M", ""),
        ("Fraud events correctly flagged/day", f"{caught_tr:,}", f"{caught_sm:,}", f"+{caught_sm - caught_tr}"),
        ("Incremental fraud recovery/year", "", f"${(caught_sm - caught_tr) * FRAUD_VALUE * DAYS / 1e6:.1f}M", ""),
        ("Regulatory penalty avoidance/year", "", f"~${PENALTY_AVOIDANCE / 1e6:.1f}M", ""),
        ("Total annualized organizational benefit", "",
         f"~${(inv_saving_day * DAYS + (caught_sm - caught_tr) * FRAUD_VALUE * DAYS + PENALTY_AVOIDANCE) / 1e6:.1f}M", ""),
        ("False-decline rate (legitimate customers)", f"{100 * tr.fp / (tr.fp + tr.tn):.2f}%", f"{100 * sm.fp / (sm.fp + sm.tn):.2f}%",
         f"{100 * (sm.fp - tr.fp) / tr.fp:+.1f}%"),
    ]
    df = pd.DataFrame(rows, columns=["dimension", "tranad", "shopmamba_mis", "improvement"])
    print(df.to_string(index=False))
    df.to_csv(TAB / "table8_business_scenario_sensitivity.regenerated.csv", index=False)
    print(f"\n(daily fraud events in scenario = {daily_pos:,}; misses: TranAD {daily_pos - caught_tr}, SHOPMAMBA-MIS {daily_pos - caught_sm})")


if __name__ == "__main__":
    main()
