#!/usr/bin/env bash
# Reproduces Figure 9: median latency vs sequence length L on the deployment CPU (2 threads).
set -euo pipefail
export PYTHONPATH=src OMP_NUM_THREADS=2 MKL_NUM_THREADS=2
python -m shopmamba.utils.latency_bench --config configs/model/shopmamba_mis.yaml --d_in 433 \
  --checkpoint results/logs/shopmamba_mis_ieee-cis_seed42/checkpoint.pt --L 64 128 256 512 1024 2048 \
  | tee results/tables/figure9_latency_vs_seqlen.tsv
