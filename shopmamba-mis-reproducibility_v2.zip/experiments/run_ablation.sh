#!/usr/bin/env bash
# Reproduces Table 7: ablation variants A1-A4 on IECIS, regenerated from the SAME pipeline and
# evaluation partition as Table 5 so the full-model row is identical to Table 5 by construction.
set -euo pipefail
export PYTHONPATH=src
for CFG in configs/model/shopmamba_mis.yaml configs/ablation/A1_no_selectivity.yaml \
           configs/ablation/A2_no_tam.yaml configs/ablation/A3_static_focal.yaml configs/ablation/A4_plain_ssm.yaml; do
  python -m shopmamba.training.train --dataset ieee-cis --config $CFG
done
python analysis/generate_confusion_matrices.py --ablation
python -m shopmamba.utils.latency_bench --config configs/model/shopmamba_mis.yaml --L 512
