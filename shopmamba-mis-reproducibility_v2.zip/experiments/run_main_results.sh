#!/usr/bin/env bash
# Reproduces Table 5 and Table 6: 9 baselines + SHOPMAMBA-MIS on IECIS, PaySim, ULB (seed 42).
# usage: bash experiments/run_main_results.sh [train|eval]
set -euo pipefail
MODE=${1:-train}; EXTRA=""; [ "$MODE" = "eval" ] && EXTRA="--eval_only"
export PYTHONPATH=src
BASELINES="LSTM AnomalyTrans DTCM TranAD DeepFraud GTAN StreamML XGBoost-Fraud Mamba-AD"
for DS in ieee-cis paysim ulb; do
  python -m shopmamba.training.train --dataset $DS --config configs/model/shopmamba_mis.yaml $EXTRA
  for B in $BASELINES; do
    python -m shopmamba.training.train --dataset $DS --baseline $B $EXTRA \
      || echo "$B $DS skipped (see baselines/external.py)" >> results/logs/skipped_baselines.txt
  done
done
python analysis/generate_confusion_matrices.py
