#!/usr/bin/env bash
# Reproduces Figure 11: precision-recall / AUPRC on ULB from saved raw test scores.
set -euo pipefail
export PYTHONPATH=src
python analysis/threshold_sensitivity.py --dataset ulb
