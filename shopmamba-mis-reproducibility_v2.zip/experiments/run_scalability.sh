#!/usr/bin/env bash
# Reproduces Figure 12: throughput vs offered transaction rate (events/s) for the streaming scorer.
set -euo pipefail
export PYTHONPATH=src OMP_NUM_THREADS=2
python - <<'PY'
import time, numpy as np, torch, yaml
from shopmamba.models.shopmamba_mis import build_from_config
from shopmamba.inference.streaming_infer import StreamingScorer
cfg = yaml.safe_load(open("configs/model/shopmamba_mis.yaml")); m = build_from_config(cfg, 433)
s = StreamingScorer(m, L=512, delta=0.5)
for rate in [500, 1000, 2000, 5000, 10000]:
    n = rate * 5; t0 = time.perf_counter()
    for i in range(n):
        s.process_element(i % 64, np.random.randn(433), t0)
    dt = time.perf_counter() - t0
    print(f"offered={rate}/s\tachieved={n/dt:.0f}/s\tp50_ms={1e3*dt/n:.2f}")
PY
