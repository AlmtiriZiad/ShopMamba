#!/usr/bin/env bash
# Reproduces Figure 10: 24 h fraud-rate drift on PaySim, DIFS (dynamic gamma_t) vs static focal (gamma=2).
set -euo pipefail
export PYTHONPATH=src
python -m shopmamba.training.train --dataset paysim --config configs/model/shopmamba_mis.yaml --run_name difs_paysim
python -m shopmamba.training.train --dataset paysim --config configs/ablation/A3_static_focal.yaml --run_name static_paysim
python analysis/drift_analysis.py --runs difs_paysim static_paysim --hours 24
