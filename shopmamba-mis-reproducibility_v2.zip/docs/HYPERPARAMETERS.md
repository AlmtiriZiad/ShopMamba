# Hyperparameters (Table 4) and the DIFS clipping rule

| Parameter | Value | Where |
|---|---|---|
| Optimizer | AdamW, lr 3e-4, weight decay 0.01, grad clip 1.0 | `configs/model/shopmamba_mis.yaml` |
| Batch / epochs | 256 / 50 | same |
| N (SSM state), M (latent), L, W | 64, 64, 512, 16 | same |
| lambda (reconstruction weight) | 0.3 | Eq. 33 |
| beta (EMA decay) | 0.99 (effective memory ~100 mini-batches) | Eq. 29 |
| gamma_min / gamma_max | 0.5 / 5.0 | Eq. 30 |
| pi_min / pi_max | 0.0002 / 0.03 | Eq. 30 |
| Seed | 42 | `utils/seeding.py` |

`gamma_t = clip(gamma_min + (gamma_max - gamma_min) (pi_max - pi_t) / (pi_max - pi_min), gamma_min, gamma_max)`.
IECIS has pi_t ~ 0.035 > pi_max, so gamma_t is clipped to 0.5 for the whole of IECIS training;
PaySim (0.0013) and ULB (0.0017) fall inside the interval and receive gamma_t ~ 4.8 and ~4.8
respectively at initialisation, then track the EMA. `tests/test_model_shapes.py::test_difs_gamma_clipping_iecis_and_paysim` asserts this.

Initial pi_0 is set to the training-split fraud rate (`configs/datasets/*.yaml: fraud_rate`).
