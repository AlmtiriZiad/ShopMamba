# Reproducing Table 8 (scenario-based organisational value)

**Table 8 is illustrative.** All values are scenario extrapolations from IECIS Table 6 integers under
stated assumptions (590,540 transactions per scenario day, $25 per alert investigation, $150 average
fraud value, $5.0 M regulatory penalty avoidance, 365 days). They are not measurements from a live deployment.

`python analysis/business_scenario_calc.py` prints every row with its formula. False alerts per day
use the test-partition FP counts directly (322 vs 129); fraud events per day scale TP by
590,540 / 114,209. Reproduced values agree with the printed table to within the rounding of that
scaling step (e.g. 19,447 vs 19,450 flagged events; $49.8 M vs $49.6 M total).
