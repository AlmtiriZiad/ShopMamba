# Reproducing Table 6 (raw confusion matrices)

Table 6 is produced by `analysis/generate_confusion_matrices.py` from `test_scores.npy`,
`test_labels.npy` and the calibrated `delta` of each run: `y_pred = scores >= delta`, then integer
TP / FP / FN / TN via `utils/metrics.confusion`. Table 5 ratios are computed from these same
integers (`utils/metrics.from_confusion`), so the two tables agree by construction.

`analysis/verify_table_consistency.py` is the regression guard: it recomputes Precision, Recall,
F1, FPR and MCC from every Table 6 row, checks them against Table 5 within one unit of the last
printed digit, checks the implied test sizes against Table 3, checks Table 7's full-model row
against Table 5, and checks the headline text claims (37 % TAM FPR reduction; +4.2 / +5.9 / +4.1 pp).
It runs on every push (`.github/workflows/ci.yml`).
