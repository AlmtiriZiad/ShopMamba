# Manuscript text ↔ table sync checklist

`analysis/verify_table_consistency.py` checks numeric consistency across Tables 1, 5, 6, and 7
automatically. It cannot parse the `.docx` manuscript text itself, so any sentence that states a
*count* or *figure* in prose must be checked by hand against the constants the script does verify.
Whenever a baseline is added/removed or a metric is recomputed, re-check every row below.

| Manuscript location | Sentence pattern | Must equal |
| --- | --- | --- |
| Introduction, Contribution C5 | "...on **N baselines** selected from top IEEE venues..." | `EXPECTED_BASELINE_COUNT` in `verify_table_consistency.py` (currently 9) |
| Section 6.4, Comparison Methods | "**N baselines** are assessed..." | same |
| Section 6.5, Discussion (immediately after Table 6) | "All measurements across all three datasets and **N baselines** are reported in Table 5." | same |
| Abstract | "+X% (F1), +Y% (F1) and +Z% (F1) respectively" | recomputed by `check_claims()` from Table 5 (SHOPMAMBA-MIS − TranAD, per dataset) |
| Contribution C5 | "F1 improvements (X–Y%)" | min/max of the same three per-dataset gains |
| Section 6.5, Discussion | "...with improvements of Xp on IECIS, Yp on PaySim and Zp on ULB." | same three gains, in pp |
| Section 6.12, single-seed limitation paragraph | "...consistent across all three datasets (X%, Y%, and Z% F1 gain respectively)..." | same |
| Conclusion | "F1 improvements of X–Y% over the strongest baselines" | same |
| Contribution C3 / Ablation H2 / Conclusion | "reducing the false positive rate by R% relatively (from A% to B%)" | recomputed by `check_claims()` from Table 7 (A2 vs. full model) |

## Why this file exists

A prior revision round fixed the baseline count in the Comparison Methods section (6→9) but left
two other prose mentions of "six baselines" unchanged, and separately fixed the ULB F1 gain figure
in the Abstract and Conclusion but not in Section 6.5 or the limitation paragraph — because no
automated check compared manuscript prose to the tables. `check_baseline_count()` and
`check_claims()` now cover the *numeric* side of this for anything derivable from the CSVs in
`results/tables/`; this table is the manual counterpart for the reader-facing sentences that
restate those numbers in prose and must be grepped/read by a human on every revision.
