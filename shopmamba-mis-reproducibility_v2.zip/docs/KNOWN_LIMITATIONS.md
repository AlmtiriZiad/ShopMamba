# Known limitations (Section 6.12)

1. **Single seed.** Every reported number is one deterministic run with seed 42. Multi-seed
   replication and paired Wilcoxon testing (`analysis/statistical_significance.py`) are future work.
2. **IECIS evaluation partition.** Results are on a chronological held-out partition of the labelled
   Kaggle training data, not on the withheld competition test set; they are not comparable with
   leaderboard scores.
3. **ULB granularity.** With 49 test positives, Recall and Precision move in steps of ~2 %; F1 values
   for baselines on ULB therefore cluster (Table 5).
4. **Cold start.** The first L-1 = 511 transactions of every account group receive WAIT and are excluded.
5. **Delayed labels.** DIFS at inference updates from analyst-confirmed labels (4 to 24 h delay), not
   per-transaction ground truth; the streaming EMA is frozen between label batches.
6. **Table 8** is scenario-based, not measured.
7. **Third-party baselines** (AnomalyTrans, TranAD, DTCM, GTAN, StreamML) depend on their upstream code;
   `baselines/external.py` pins the sources and wraps them behind a common interface.
