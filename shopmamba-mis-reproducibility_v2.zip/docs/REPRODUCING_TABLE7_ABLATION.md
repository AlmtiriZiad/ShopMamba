# Reproducing Table 7 (ablation on IECIS)

`bash experiments/run_ablation.sh` trains the full model and A1 to A4 from `configs/ablation/*.yaml`
on the identical IECIS split, threshold rule and evaluation partition used for Table 5, so the
full-model row equals the SHOPMAMBA-MIS / IECIS row of Table 5 (F1 0.973, FPR 0.12 %) by construction.

| Variant | Config change | What it tests |
|---|---|---|
| A1 | `selective: false` | H1: input-dependent Delta_t, B_t in SSAE |
| A2 | `use_tam: false` | H2: local causal attention window W = 16 |
| A3 | `static_gamma: 2.0` | H3: dynamic gamma_t (DIFS) vs static focal loss |
| A4 | all three | plain fixed-parameter SSM |

Latency column: `python -m shopmamba.utils.latency_bench --config <variant.yaml> --L 512` on the
deployment CPU with 2 threads (median of 1,000 passes after 50 warm-ups).
