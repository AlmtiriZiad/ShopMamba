# Reproducing Table 5 (main detection performance)

1. `conda env create -f environment.yml && conda activate shopmamba`
2. Download the three Kaggle datasets into `data/raw/` (see `data/README.md`) and run `make data`.
   This writes `data/processed/*.parquet` and `data/splits/*_split.json`, asserting the test sizes
   114,209 / 3,997 (IECIS), 953,161 / 1,239 (PaySim), 28,481 / 49 (ULB).
3. `bash experiments/run_main_results.sh train` trains SHOPMAMBA-MIS and the nine baselines on each
   dataset with seed 42 (Table 4). Each run writes `results/logs/<run>/{checkpoint.pt, test_scores.npy,
   test_labels.npy, metrics.json}`. Third-party baselines need their upstream packages installed
   (`src/shopmamba/baselines/external.py`); missing ones are listed in `results/logs/skipped_baselines.txt`.
4. Threshold delta is calibrated on the validation split to the largest recall with FPR <= 0.5 %
   (`utils/metrics.calibrate_threshold`), never on the test split.
5. `python analysis/generate_confusion_matrices.py` rebuilds `table5_*.regenerated.csv` and
   `table6_*.regenerated.csv` from the raw predictions. Diff them against the committed tables and run
   `python analysis/verify_table_consistency.py --strict`.

Cold-start windows (first L-1 rows of each account group) receive WAIT and are excluded from all metrics.
